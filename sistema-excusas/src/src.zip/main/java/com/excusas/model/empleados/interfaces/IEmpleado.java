package com.excusas.model.empleados.interfaces;

public interface IEmpleado {
    String getNombre();
    String getEmail();
    int getLegajo();
}