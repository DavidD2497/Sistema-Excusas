package com.excusas.model.prontuarios.interfaces;

import com.excusas.model.prontuarios.Prontuario;

public interface IObserver {
    void actualizar(Prontuario prontuario);
}

