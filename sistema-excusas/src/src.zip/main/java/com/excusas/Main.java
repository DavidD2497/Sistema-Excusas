package com.excusas;

public class Main {
    public static void main(String[] args) {
    }
}

